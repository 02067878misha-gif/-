//go:build windows

package main

import (
	"syscall"
	"unsafe"
)

func openBrowser(url string) error {
	shell := syscall.NewLazyDLL("shell32.dll").NewProc("ShellExecuteW")
	op, _ := syscall.UTF16PtrFromString("open")
	u, _ := syscall.UTF16PtrFromString(url)
	ret, _, _ := shell.Call(0, uintptr(unsafe.Pointer(op)), uintptr(unsafe.Pointer(u)), 0, 0, 1)
	if ret <= 32 {
		return syscall.EINVAL
	}
	return nil
}
func showMessage(s string) {
	proc := syscall.NewLazyDLL("user32.dll").NewProc("MessageBoxW")
	a, _ := syscall.UTF16PtrFromString(s)
	b, _ := syscall.UTF16PtrFromString("Геологический картограф")
	proc.Call(0, uintptr(unsafe.Pointer(a)), uintptr(unsafe.Pointer(b)), 0)
}
