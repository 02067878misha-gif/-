package main

import (
	"crypto/rand"
	"embed"
	"encoding/hex"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"sync/atomic"
	"time"
)

//go:embed index.html styles.css js/*.js
var assets embed.FS

var lastSeen int64

func main() {
	var secretBytes [24]byte
	if _, err := rand.Read(secretBytes[:]); err != nil {
		showError("Не удалось запустить: " + err.Error())
		return
	}
	secret := hex.EncodeToString(secretBytes[:])
	listener, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		showError("Не удалось открыть локальный порт: " + err.Error())
		return
	}
	atomic.StoreInt64(&lastSeen, time.Now().Unix())
	mux := http.NewServeMux()
	// Serve bundled JS and CSS as local files. No CDN or network dependency.
	// The home page and control endpoints retain their original secret check.
	staticFiles := http.FileServer(http.FS(assets))
	serveAsset := func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			http.Error(w, "Метод не поддерживается", http.StatusMethodNotAllowed)
			return
		}
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		staticFiles.ServeHTTP(w, r)
	}
	mux.HandleFunc("/styles.css", serveAsset)
	mux.HandleFunc("/js/", serveAsset)
	shutdown := make(chan struct{})
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" || r.Method != http.MethodGet {
			http.NotFound(w, r)
			return
		}
		if r.URL.Query().Get("key") != secret {
			http.Error(w, "Доступ запрещён", http.StatusForbidden)
			return
		}
		atomic.StoreInt64(&lastSeen, time.Now().Unix())
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Content-Security-Policy", "default-src 'self' 'unsafe-inline' data: blob:; connect-src 'self'; img-src 'self' data: blob:; object-src 'none'")
		b, e := assets.ReadFile("index.html")
		if e != nil {
			http.Error(w, e.Error(), 500)
			return
		}
		_, _ = w.Write(b)
	})
	mux.HandleFunc("/ping", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Query().Get("key") != secret {
			http.Error(w, "Доступ запрещён", 403)
			return
		}
		atomic.StoreInt64(&lastSeen, time.Now().Unix())
		w.WriteHeader(http.StatusNoContent)
	})
	mux.HandleFunc("/exit", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost || r.URL.Query().Get("key") != secret {
			http.Error(w, "Доступ запрещён", 403)
			return
		}
		w.WriteHeader(http.StatusNoContent)
		select {
		case shutdown <- struct{}{}:
		default:
		}
	})
	server := &http.Server{Handler: mux, ReadHeaderTimeout: 5 * time.Second, IdleTimeout: 60 * time.Second}
	go func() {
		if e := server.Serve(listener); e != nil && e != http.ErrServerClosed {
			log.Println(e)
		}
	}()
	url := fmt.Sprintf("http://127.0.0.1:%d/?key=%s", listener.Addr().(*net.TCPAddr).Port, secret)
	if err := openBrowser(url); err != nil {
		showError("Откройте в браузере: " + url)
	}
	ticker := time.NewTicker(25 * time.Second)
	defer ticker.Stop()
	for {
		select {
		case <-shutdown:
			_ = listener.Close()
			return
		case <-ticker.C:
			if time.Now().Unix()-atomic.LoadInt64(&lastSeen) > 240 {
				_ = listener.Close()
				return
			}
		}
	}
}
func showError(s string) { fmt.Fprintln(os.Stderr, s); showMessage(s) }
