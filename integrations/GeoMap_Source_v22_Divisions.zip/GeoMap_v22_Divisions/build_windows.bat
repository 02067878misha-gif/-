@echo off
cd /d "%~dp0"
where go >nul 2>nul || (echo Install Go from https://go.dev/dl/ & pause & exit /b 1)
set GOOS=windows
set GOARCH=amd64
set CGO_ENABLED=0
go build -trimpath -ldflags="-s -w -H=windowsgui" -o "GeologicalMap.exe" .
if errorlevel 1 (echo BUILD FAILED) else (echo Built: GeologicalMap.exe)
pause
