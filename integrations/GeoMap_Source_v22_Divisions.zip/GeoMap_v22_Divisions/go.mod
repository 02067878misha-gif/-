module geologicalmap

go 1.21
