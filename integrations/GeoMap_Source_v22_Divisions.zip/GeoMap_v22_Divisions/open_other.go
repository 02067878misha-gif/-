//go:build !windows

package main

import (
	"fmt"
	"os"
	"os/exec"
)

func openBrowser(url string) error {
	if os.Getenv("GEOMAP_TEST") == "1" {
		fmt.Println("LOCAL_APP_URL=" + url)
		return nil
	}
	return exec.Command("xdg-open", url).Start()
}
func showMessage(s string) { fmt.Fprintln(os.Stderr, s) }
